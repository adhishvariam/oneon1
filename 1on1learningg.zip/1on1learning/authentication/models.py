# from 1on1t import 
from mongoengine import *

class Login(Document):
    username = StringField(default="")
    password = StringField(default="")

class Signup(Document):
    firstname = StringField(default="")
    lastname = StringField(default="")
    email = StringField(default="")
    phone = StringField(default="")
    username = StringField(default="")
    password = StringField(default="")
    current_address = StringField(default="")
    permanent_address = StringField(default="")
    role = StringField(default="")
    status = StringField(default="")
    signup_source = StringField(default="")
    auth_token = StringField(default="")
    date_created = StringField(default="")
    date_modified = StringField(default="")