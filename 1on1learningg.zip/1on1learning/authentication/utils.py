from flask import Flask, request, jsonify, render_template
from oneon1learning import app
from oneon1learning import db
from .models import *
import random
import json
from flask_jwt_extended import JWTManager, create_access_token, get_jwt_identity, jwt_required
import datetime
import urllib
from threading import Thread

jwt = JWTManager(app)  # initialize JWTManager

from functools import wraps

def validate_access_token(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Do something with your request here
        data = request.get_json()
        print(data)
        token = request.headers.get('Authorization').split()[1]
        print(token)
        access = Signup.objects(access_token=token)
        print(access, "access-------")

        if not access:
            responce = {}
            responce['status'] = False
            responce['status_code'] = 401
            responce['data'] = []
            responce['description'] = 'User failed decorator'
            return jsonify(responce)
        return f(*args, **kwargs)

    return decorated_function


# Add your other routes and functions here
