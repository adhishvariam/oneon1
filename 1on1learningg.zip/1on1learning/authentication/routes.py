from .models import *
from oneon1learning import app 
from flask import Flask,request,jsonify
from flask_jwt_extended import JWTManager, create_access_token, get_jwt_identity, jwt_required
import datetime
# import hashlib
# import urllib
# import redis
from threading import Thread

jwt = JWTManager(app) # initialize JWTManager
app.config['JWT_SECRET_KEY'] = '46bb34t76d405e02uc6abc4b9605amjoneon1learning'
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = datetime.timedelta(days=1)
app.config['JWT_BLACKLIST_ENABLED'] = True
app.config['JWT_BLACKLIST_TOKEN_CHECKS'] = ['access', 'refresh']

@app.route('/test/login', methods=['POST'])
def login():
    try:
        request_data = request.json
        username = request_data['username']
        password = request_data['password']


        # Perform the login authentication here (you might need to customize this part)
        # For simplicity, let's assume the login is successful if the username and password are not empty strings.
        if username and password:
            # If the login is successful, you can include user information in the response
            if Signup.objects(username=username, password=password):
                user = Signup.objects.get(username=username, password=password)
                access_token = create_access_token(identity=str(user.id))
                Signup.objects(username=username,id=str(user.id)).update(set__auth_token=access_token)
                response_data = {
                    'status': 'success',
                    'message': 'Login Succesfully',
                    'data': access_token
                }
                return jsonify(response_data), 200
            else :
                response_data = {
                    'status': 'error',
                    'message': 'Login Failed. Please provide valid credentials.',
                    'data': None
                }
                return jsonify(response_data), 401

        else:
            pass
            # If the login is unsuccessful (missing username or password), return an error response
            

    except KeyError as e:
        # Handle the case where the JSON data is missing 'username' or 'password'
        response_data = {
            'status': 'error',
            'message': f"Missing key in JSON data: {str(e)}",
            'data': None
        }
        return jsonify(response_data), 400

    except Exception as e:
        # Handle any other unexpected exceptions
        # Log the error (you might want to use a logging library for this)
        print(f"Error occurred during login: {str(e)}")

        response_data = {
            'status': 'error',
            'message': 'An error occurred while processing the request',
            'data': None
        }
        return jsonify(response_data), 500


    

@app.route('/test/signup', methods=['POST'])
def signup():
    try:
        request_data = request.json
        firstname = request_data['firstname']
        lastname = request_data['lastname']
        email = request_data['email']
        phone = request_data['phone']
        username = request_data['username']
        password = request_data['password']
        current_address = request_data['current_address']
        permanent_address = request_data['permanent_address']
        role = request_data['role']
        signup_source = request_data['signup_source']

        signup = Signup(firstname=firstname, lastname=lastname, email=email, password=password, phone=phone, username=username, current_address=current_address, permanent_address=permanent_address, role=role, signup_source=signup_source)
        signup.save()
        print(signup.id)
        if signup.id:
            access_token = create_access_token(identity=str(signup.id))
            Signup.objects(username=username,id=str(signup.id)).update(set__auth_token=access_token)
            response_data = {
                'status': 'success',
                'message': 'Username Created Successfully',
                'data': {'access_token': access_token}  # Include the newly created user's ID in the response
            }
            return jsonify(response_data), 200
        else:
            response_data = {
                'status': 'error',
                'message': 'Failed to create user',
                'data': None
            }
            return jsonify(response_data), 500

    except KeyError as e:
        # Handle the case where the JSON data is missing a required field
        response_data = {
            'status': 'error',
            'message': f"Missing key in JSON data: {str(e)}",
            'data': None
        }
        return jsonify(response_data), 400

    except Exception as e:
        # Handle any other unexpected exceptions
        # Log the error (you might want to use a logging library for this)
        print(f"Error occurred during signup: {str(e)}")

        response_data = {
            'status': 'error',
            'message': 'An error occurred while processing the request',
            'data': None
        }
        return jsonify(response_data), 500
    
