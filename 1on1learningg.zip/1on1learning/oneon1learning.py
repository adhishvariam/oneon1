from mongoengine import *
from flask import Flask,request,jsonify
from mongoengine import connect
# from authentication import models
import json

db = connect('learning', host='127.0.0.1', port=27017)
print("success")

app = Flask(__name__)

from authentication import routes

@app.route('/learning')
def hello():
    return 'Hello, World!'


if __name__ == "__main__":
    app.run( debug=True) 
    # app(host='0.0.0.0', port=80) 